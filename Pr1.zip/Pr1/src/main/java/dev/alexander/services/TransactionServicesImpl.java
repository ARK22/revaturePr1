package dev.alexander.services;

import java.util.ArrayList;

import dev.alexander.models.transactions;

public class TransactionServicesImpl implements TransactionServices {

	@Override
	public ArrayList<transactions> getAllTransByEmpId(int emp_id) {
		// TODO Auto-generated method stub
		return null;
	}

}
