package dev.alexander.repos;

public interface TransactionRepos {

}
